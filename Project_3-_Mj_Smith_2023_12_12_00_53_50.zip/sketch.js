var player;
var idleAnimation;
var walkAnim;
var screens = [];
var numScreens = 5;
var bg;
var framerate;
var r;

function preload() {
  
  var screen1 = loadImage('background1.png');
  var screen2 = loadImage('background2.png');
  var screen3 = loadImage('background3.png');
  var screen4 = loadImage('background4.png');
  var screen5 = loadImage('background5.png');
  screens = [screen1,screen2,screen3,screen4,screen5];
  
  idleAnimation = loadAnimation("pixil-fox-0.png");
  walkAnim = loadAnimation("pixil-fox-0.png")
  
}

function setup() {
  bg = loadImage(screens);
  createCanvas(600, 400);
  saveCanvas('myCanvas.jpg');
  r = floor(random(6));
  frameRate(1)
  player = createSprite(400,500);
  player.addAnimation("idle", idleAnimation);
  player.addAnimation("walk", walkAnim);
}

function draw() { 
 background(bg);
  //background(255);
  imageMode(CENTER);
  var randoImg = random(screens)
  image(randoImg, width /1, height /1);
  
  if (player.position.y > 300) {
    player.position.y = 300;
  }
  player.velocity.y++;
  
  drawSprites();
  
  if (player.position.x == 600) {
    
   resizeCanvas(700, 400);
  player.position.x = 600;
     
  } 
  fill(0);
  rect(600, 200,5,50);
   if (player.position.x< 0) {
    player.position.x = 10;//boarders
  }
   if (player.position.x >= 600) {
    player.position.x = 601;
    }
   if (player.position.x >= 600) {
     resizeCanvas(700, 600);
     fill(0);
  rect(0,0,width,height); 
       player.position.x = 600;
    }
}

function keyPressed() {
  if (keyCode == LEFT_ARROW) {
    if (player.getAnimationLabel() !== "walk") {
      player.changeAnimation("walk");
      player.setSpeed(-100, 0);
      player.mirrorX(-1);
    }
  } else if (keyCode == RIGHT_ARROW) {
    if (player.getAnimationLabel() !== "walk") {
      player.changeAnimation("walk");
      player.setSpeed(100, 0);
      player.mirrorX(1);
    }
  } else if (keyCode == UP_ARROW) {
    if (player.getAnimationLabel() !== "walk") {
      player.changeAnimation("walk");
      player.velocity.y = -20;
    }
  } else {
    if (player.getAnimationLabel() !== "idle") {
      player.changeAnimation("idle");
      player.setSpeed(0, 0);
    }
  }
}

function keyReleased() {
  player.setSpeed(0, 0);
  player.changeAnimation("idle");
}